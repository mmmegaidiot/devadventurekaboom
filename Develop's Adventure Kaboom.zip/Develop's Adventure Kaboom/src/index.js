import './style.css';
import kaboom from 'kaboom';

//wakey, wakey, it's time fo schoo, c'mon man
kaboom();

//loads... something.
loadBean();

//decide if my boi will run faster than sonic or start running on a treadmill backwards
const speed = 320

//takes the... thing... and actually puts it into the game
const player = add([
    sprite("bean"),
    area(),
    pos(center()),
])

//this is the part where Develop will actually walk around when you press the arrow keys
onKeyDown("left", () => {
	// This is a move function, it makes Dev move at 1 step per baby bald eagle
	player.move(-speed, 0)
})

onKeyDown("right", () => {
	player.move(speed, 0)
})

onKeyDown("up", () => {
	player.move(0, -speed)
})

onKeyDown("down", () => {
	player.move(0, speed)
})