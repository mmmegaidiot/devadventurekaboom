//hang on gamers, let me fetch something reaaal quick
import './style.css';
import kaboom from 'kaboom';

//wakey, wakey, it's time fo schoo, c'mon man
kaboom();

//loads every asset for Develop's Adventure so that it can call upon them as needed

loadBean();

//decide if my boi will run faster than sonic or start running on a treadmill backwards
const speed = 320

//takes the... thing... and actually puts it into the game
const player = add([
    sprite("bean"),
    area(),
    pos(center()),
])

//this is the part where Develop will actually walk around when you press the arrow keys
onKeyDown("left", () => {
	// This is a move function, it makes Dev move at 1 step per baby bald eagle
	player.move(-speed, 0)
})

onKeyDown("right", () => {
	player.move(speed, 0)
})

onKeyDown("up", () => {
	player.move(0, -speed)
})

onKeyDown("down", () => {
	player.move(0, speed)
})

// this turns the game into a layer cake, and anything not defined automatically sorts itself into "game"
layers([
    "bg",
    "game",
    "ui",
 "game"])

 add([
	text("imagine something useful, idk"),
	layer("ui"),
    fixed(),
])

//i like the chekerboard pattern, don't get me wrong, but the sky looks better
loadSprite("sky","./sprites/skytest.jpg").then(
	add([
	  sprite("sky"),
	  pos(0,0)
	])
  ) 